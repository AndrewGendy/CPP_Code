
// Write code for the following member functions:
/*
Constructor. The constructor should accept the person�s name and member identification number. 
						These values should be assigned to the object�s memberName and memberID data members. 
						The constructor should also assign 0 to numBooks and purchaseAmt.

Accessor.	Appropriate accessor functions to get the values stored in an object�s memberName, 
					memberID, numBooks, and purchaseAmt data members.


addNewPurchase. The addNewPurchase function should accept the number of books for a new purchase and 
									the total amount of the purchase in dollars as arguments. 
									The function should add these argument values to the existing numBooks and purchaseAmt data member.

*/