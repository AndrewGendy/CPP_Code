#ifndef MEMBER_H
#define MEMBER_H

#include <string>
#include <iostream>

using namespace std;

// define the class members and member function prototypes here

#endif