
// Program 8: memberType Class
	//Demonstrate the class in a client program that creates a memberType object and 
	//	then calls the addNewPurchase function twice (representing 2 new purchases).
	//	
	//	After each new purchase, display the member�s id and name along with 
	//	the current number of books and current purchase amount.

#include <iostream>
#include <string>
#include <iomanip>



using namespace std;

int main()
{


	system("pause");
	return 0;
} // end main